# claude_split — split nested-cycle search (C12)

Working folder created by Claude on 2026-10-03. Nothing outside this folder was touched.
Job IDs submitted from here are logged in `JOBS.txt`.

## Layout
- `src/`      code snapshot (iterative_nested.cpp, iterative_nested_c12_split.cpp, hds_kplanar.h, ...) + `include/` (copied from ~/quasiplanar_enumerator)
- `bin/`      binaries; each production run uses its own frozen copy (e.g. `bin/split_c12_l0_p1`)
- `runs/RUN/tI/`  output of array task I: `children.jsonl` (one drawing per line), `done_units.txt`, `extensible.txt`
- `logs/`     Slurm logs (`claude_split_<jobid>_<task>.log/.err`)
- `build.slurm`, `search.slurm`

## Build (login node is fine, needs the Boost module)
    bash -l
    module load stack/2024-06 boost
    g++ -O3 -Wall -std=c++17 -I./src/include src/iterative_nested_c12_split.cpp -o bin/split

## How the split works
Every task runs the same deterministic DFS down to `DEPTH` gadget edges, numbers the prefixes it reaches
(0,1,2,...) and only searches below prefix j if j % TASKS == task index. Finished prefixes are appended to
`done_units.txt`; resubmitting the same array (same RUN, TASKS, DEPTH, binary and options) resumes and skips them.
Options that prune above DEPTH (REACH_EVERY_EDGE_FROM) change the numbering: never mix settings within a RUN.
FINAL_FACE_EVERY_EDGE_FROM >= DEPTH does not change the numbering.

    ./bin/split count <depth> <passes> [parents_file]          # number of prefixes at a depth
    ./bin/split search <i> <N> <depth> <passes> <outdir> [parents_file]
    ./bin/split merge <outdir> <task_dir>...                   # dedup by canonical code

## Monitoring
    squeue -u $USER -n claude_split
    grep PROGRESS logs/claude_split_<jobid>_<task>.log | tail -1     # every 30 min
    cat runs/<RUN>/t*/done_units.txt | wc -l                          # prefixes finished in total
    cat runs/<RUN>/t*/children.jsonl | wc -l                          # children found (before global dedup)

## Resubmit / resume (e.g. after the time limit)
Same command as in JOBS.txt (same RUN, TASKS, DEPTH, BIN and options).

## Merge level 0 -> parents for level 1
    ./bin/split merge runs/<RUN>_merged runs/<RUN>/t*
Writes parents.jsonl (distinct drawings, one per line), parents.txt (usable as parents_file) and
extensible.txt. Parents are loaded one at a time by `search`, so any number of them is fine.

## Final drawings
    ./bin/split merge_solutions runs/<FINAL> runs/<PASS2_RUN>*
Dedups the Pass 2 complete drawings (solutions.jsonl) up to strong isomorphism (same notion as
are_isomorphic in iso.h, cross-checked), writes final.jsonl and final_<k>.json/.graphml (first 1000).

## Current run (started 2026-10-03 18:39): `c12_l0_p2`, job 15987635
Level 0 (base drawing), Pass 1 only, 100 tasks, DEPTH=11 (385,138 prefixes), binary `bin/split_c12_l0_p2`,
options `REACH_EVERY_EDGE_FROM=1 FINAL_FACE_EVERY_EDGE_FROM=1`, progress line every 30 min, 7-day limit.
(`c12_l0_p1` was the earlier run with an older binary; cancelled, its output is not used.)

Options (both verified exact on C6, i.e. same children as without them):
- REACH_EVERY_EDGE_FROM=1: reachability check + fail-first reordering of the remaining gadget edges after every
  edge (not only at the checkpoints). Edges with an unplaced endpoint are skipped (the old "fail safe" return
  false is removed: it pruned valid branches once edges are reordered).
- FINAL_FACE_EVERY_EDGE_FROM=1: Pass 1 only; once all new cycle vertices are placed, prune if no face can still
  reach flow >= cycle_size (per edge piece capacity bound 4/2/1/0 for ncr 0/1/2/3, sound for all completions).

### Is Pass 1 done?
All 100 tasks have exited normally (log ends with the "SEARCH task ..." summary) and
    cat runs/c12_l0_p2/t*/done_units.txt | wc -l      # == 385138
If tasks hit the 7-day limit: resubmit the exact same sbatch command from JOBS.txt; they resume.
Pass 1 finished on 2026-10-03 at about 20:15 (all 385,138 prefixes, 199,799 children before global dedup).

## Post-processing (job 15995303, `post.slurm`)
1. `merge` -> `runs/c12_l0_p2_merged/parents.jsonl` (distinct intermediate drawings)
2. Pass 2 on all of them (one process, ~1.5 ms per parent locally) -> `runs/c12_l1_p2/solutions.jsonl`
3. `merge_solutions` -> `runs/c12_final/` (distinct final drawings)
